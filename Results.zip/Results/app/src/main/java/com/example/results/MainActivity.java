package com.example.results;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private static final String tag = "==MainActivity==";
    public static final String REQUEST_RESULT="REQUEST_RESULT";
    private ActivityResultLauncher<Intent> Launch4Result;
    public void onClickSwitchActivity(View view) {
        Log.d(tag, "onClickSwitchActivity");
        EditText editText = (EditText)findViewById(R.id.editTextText);
        String text = editText.getText().toString();
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra(Intent.EXTRA_TEXT,text);
        Launch4Result.launch(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(tag, "onCreate");
        Launch4Result = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                this::handleResult);
    }
    private static String loginText;
    public void nextActivity (View view) {
        Log.d(tag, "nextActivity button pressed");
        EditText loginEdit = findViewById(R.id.editTextText);
        Intent switch2Activity2 = new Intent(MainActivity.this, MainActivity2.class);
// include data with the intent
        loginText = loginEdit.getText().toString();
        switch2Activity2.putExtra("loginText", loginText);
        startActivity(switch2Activity2);
    }
    public static String getLoginText() {return loginText;}

    private void handleResult(ActivityResult result) {
        int resultCode = result.getResultCode();
        if (resultCode == RESULT_OK) {
            Intent data = result.getData();
            Log.d(tag, "RESULT_OK. Result Data =" +
                    data.getIntExtra(REQUEST_RESULT, 0));
        } else if (resultCode == RESULT_CANCELED) {
            Log.d(tag, "RESULT_CANCELED. ");
        } else {
            Log.d(tag, "Unexpected Error XXX, resultCode = " + resultCode);
        }
    }
}