package com.example.results;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {
    private final static String tag = "==Activity Two==";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView textView = (TextView)findViewById(R.id.textView);
        String extra = "";
        if (getIntent()!=null && getIntent().hasExtra("loginText")) {
            extra = getIntent().getStringExtra("loginText");
            textView.setText(getIntent().getStringExtra("loginText"));
        }
        Log.d(tag, "onCreate() recvd '" + extra + "'");
        if (getIntent()!=null) {
            Log.d(tag, "getintent is not null");
            if (getIntent().hasExtra(Intent.EXTRA_TEXT)) {
                Log.d(tag,"there should be a string here");
            } else {
                Log.d(tag,"Drake, where's the string?");
            }
            if (getIntent().hasExtra("loginText")) {
                Log.d(tag,"there we go.");
            }
        }
    }

    public void onClickClose(View view) {
        Log.d(tag, "onClickClose()");
        Intent returnIntent = new Intent();
        returnIntent.putExtra(MainActivity.REQUEST_RESULT, 42);
        setResult(RESULT_OK, returnIntent);
        finish();
    }

    public void onClickCancel(View view) {
        Log.d(tag, "onClickClose()");
        finish();
    }
}