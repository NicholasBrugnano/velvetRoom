package com.example.wk6ex2;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    public static final String tag = "Whatever";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v) {
        if (v.getId() == R.id.toast0) {
// chain
            Toast.makeText(this, "Basic Toast", Toast.LENGTH_LONG).show();
        } else if (v.getId() == R.id.toast1) {
            Toast t2 = Toast.makeText(this, "Unchained =Short=",
                    Toast.LENGTH_SHORT);
            t2.show();
        }
        if (snackBar != null && snackBar.isShown()) {
            snackBar.dismiss();
            TextView tview = findViewById(R.id.textView);
            tview.setText("Snackbar dismissed via toast button");
        }
    }

    // declare the Snackbar reference at the class level
// so it can be shared across methods.
    private Snackbar snackBar;
    public void snackBarH(View b1) {
        TextView tview = findViewById(R.id.textView);
        if (b1.getId() == R.id.buttons2) {
            tview.setText("Snackbars are Good!");
        } else {
            tview.setText("Snackbars are Very Good :)");
        }
    }
    public void onShowSnackBar(View v) {
// SnackBars support the duration "LENGTH_INDEFINITE"
        snackBar = Snackbar.make(v, "This is a SnackBar",
                Snackbar.LENGTH_INDEFINITE);
        snackBar.setBackgroundTint(Color.rgb(200,0,100));
// Get the inflater for the current activity's view
        LayoutInflater inflater = getLayoutInflater();
// inflate the custom_snackbar_view created previously
        View customSnackView = inflater.inflate(R.layout.sbar, null);
// we perform a tricky cast. SnackBar.getView() returns a view,
// but we can interpret it as a ViewGroup. We need this to
// be able to modify it by calling addView, a ViewGroup method.
        ViewGroup snackbarLayout = (ViewGroup) snackBar.getView();
// Makes a border around the layout
        snackbarLayout.setPadding(25, 25, 25, 25);
// add the custom snack bar layout to snackbar layout
        snackbarLayout.addView(customSnackView, 0);
// register the button from the custom_snackbar_view layout file
        Button bsnack1 = customSnackView.findViewById(R.id.buttons1);
        bsnack1.setOnClickListener(this::snackBarH);
// register the button from the custom_snackbar_view layout file
        Button bsnack2 = customSnackView.findViewById(R.id.buttons2);
        bsnack2.setOnClickListener(this::snackBarH);
        snackBar.show();
    }
}